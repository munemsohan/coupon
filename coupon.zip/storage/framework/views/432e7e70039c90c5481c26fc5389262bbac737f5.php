<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"/>

<div class="row">

	<div class="col-md-6 col-md-offset-3">

		<table class="table table-striped table-hover table-centered">
	<thead>
		<tr>
			<th>Seller</th>
			<th>Coupon Count</th>
			<th>Total Amount</th>
			<th>Total Commission</th>
		</tr>
	</thead>
	<tbody>

		<?php $__currentLoopData = $sellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($seller->name); ?></td>
			<td><?php echo e($seller->coupon_count); ?></td>
			<td><?php echo e($seller->total_amount); ?></td>
			<td><?php echo e($seller->total_commission); ?></td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
		
	</div>
	

</div>


<span><?php echo e($sellers->links('vendor.pagination.custom')); ?></span>
<?php /**PATH C:\xampp\htdocs\coupon\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>