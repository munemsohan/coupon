<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"/>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.1.5/dist/sweetalert2.all.min.js"></script>

<div class="row">

	<div class="col-md-6 col-md-offset-3">

		<table class="table table-striped table-hover text-center">
			<thead>
				<tr>
					<th>Seller</th>
					<th>Coupon Count</th>
					<th>Total Amount</th>
					<th>Total Commission</th>
					<th></th>
				</tr>
			</thead>
			<tbody>

				<?php $__currentLoopData = $sellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($seller->name); ?></td>
					<td><?php echo e($seller->coupon_count); ?></td>
					<td><?php echo e($seller->total_amount); ?></td>
					<td style="color:red"><b><?php echo e($seller->total_commission); ?><b></td>
					<td><?php if($seller->total_commission > 0): ?> <button id="<?php echo e($seller->id); ?>" class="delete_btn btn btn-success">Withdraw</button> <?php endif; ?></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
		
	</div>
	
</div>

<span><?php echo e($sellers->links('vendor.pagination.custom')); ?></span>

<script type="text/javascript">

	$(document).ready(function(){
		$('.delete_btn').click(function(){
			$.ajax({
				type: "GET",
				url: "<?php echo e(url('/')); ?>/admin/withdraw/"+this.id,
				success: function(msg){

					Swal.fire(
						'Withdrawn!',
						'Seller Withdraw Successful',
						'success'
						);

					location.reload();
				}
			});
		});
	});
</script>
<?php /**PATH C:\xampp\htdocs\coupon\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>